namespace Database;

public interface IRawDataLocation{
    string Path {get;}
}