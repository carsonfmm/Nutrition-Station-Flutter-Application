

class Configs {
    public static string Location => "./database.db";
}