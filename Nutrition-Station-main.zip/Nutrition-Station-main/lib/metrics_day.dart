class MetricsDay {
  final String title;
  final DateTime day;

  const MetricsDay ({
    required this.title,
    required this.day,
  });
}