//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import path_provider_foundation

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  PathProviderPlugin.register(with: registry.registrar(forPlugin: "PathProviderPlugin"))
}
