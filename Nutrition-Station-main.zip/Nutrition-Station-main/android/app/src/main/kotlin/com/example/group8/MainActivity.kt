package com.example.group8

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
